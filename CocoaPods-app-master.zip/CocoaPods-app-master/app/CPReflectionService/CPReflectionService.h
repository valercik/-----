#import <Foundation/Foundation.h>
#import "CPReflectionServiceProtocol.h"

@interface CPReflectionService : NSObject <CPReflectionServiceProtocol>
@end
