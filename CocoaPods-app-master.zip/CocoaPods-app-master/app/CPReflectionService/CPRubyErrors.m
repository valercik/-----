#import "CPRubyErrors.h"

NSString *const CPErrorDomain = @"org.cocoapods.app.ErrorDomain";
NSString *const CPErrorName = @"exception-name";
NSString *const CPErrorRubyBacktrace = @"backtrace";
NSString *const CPErrorObjCBacktrace = @"objc-backtrace";

