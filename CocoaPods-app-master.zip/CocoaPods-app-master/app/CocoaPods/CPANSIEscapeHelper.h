@import ANSIEscapeHelper;

/// Provides CocoaPods specific ANSI colors and fonts.

@interface CPANSIEscapeHelper : AMR_ANSIEscapeHelper

@end
