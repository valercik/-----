@import Foundation;

@interface CPDebuggerCheck : NSObject

+ (BOOL)isInDebugger;

@end
