#import <Cocoa/Cocoa.h>

@interface CPWhiteCheckedButton : NSButton

@end
