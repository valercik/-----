#import <Cocoa/Cocoa.h>

@interface CPBorderedButton : NSButton
@end

@interface CPBorderedButtonCell : NSButtonCell

@end