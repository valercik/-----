import Cocoa

class CPTestHelper: NSObject, NSApplicationDelegate {

}
