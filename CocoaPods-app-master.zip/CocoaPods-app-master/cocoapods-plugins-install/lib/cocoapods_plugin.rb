require 'pod/command/plugins/install'
